<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Stay Layout</title>

    <style>
        body{
            font-family: DejaVu Sans, sans-serif;
            font-size:12px;
        }

        table{
            width:100%;
            border-collapse: collapse;
            margin-bottom:20px;
        }

        th,td{
            border:1px solid #ddd;
            padding:6px;
            text-align:left;
        }

        th{
            background:#f3f4f6;
        }

        .booking-title{
            background:#e5e7eb;
            padding:6px;
            font-weight:bold;
        }

        .guest-box{
            background:#eff6ff;
            padding:4px;
            border-radius:4px;
        }
    </style>
</head>

<body>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookingId => $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="booking-title">
    Booking #<?php echo e($bookingId); ?>

</div>

<table>

<thead>
<tr>
<th>Room</th>
<th>Type</th>
<th>Room Type</th>
<th>Bed 1</th>
<th>Bed 2</th>
<th>Bed 3</th>
<th>Bed 4</th>
<th>Bed 5</th>
<th>Bed 6</th>
<th>Total Occupied</th>
<!--<th>Available</th>-->
</tr>
</thead>

<tbody>

<?php
    $grandTotal = 0;
?>

<?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomId => $beds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
    $room = $beds->first();
    $bedMap = $beds->keyBy('bed_number');
    $totalBeds = $room->room->no_of_beds ?? 6;

    // Captain exclude karke count karenge
    $occupiedBeds = $beds->where('is_captain', 0)->count();
    $availableBeds = $totalBeds - $occupiedBeds;

    $grandTotal += $occupiedBeds;
?>

<tr>

<td><?php echo e($roomId); ?></td>

<td><?php echo e(ucfirst($room->room->room_type ?? 'other')); ?></td>

<td><?php echo e(ucfirst($room->room_type ?? 'other')); ?></td>

<?php for($i=1;$i<=6;$i++): ?>

<td>

<?php if(isset($bedMap[$i])): ?>

<div class="guest-box">

<?php echo e($bedMap[$i]->guest_name); ?>


<?php if($bedMap[$i]->is_captain): ?>
👑 (Captain)
<?php endif; ?>

<br>

<small>
<?php echo e(ucfirst($bedMap[$i]->guest_gender)); ?>

</small>

</div>

<?php else: ?>

<?php if($i <= $totalBeds): ?>
Empty
<?php endif; ?>

<?php endif; ?>

</td>

<?php endfor; ?>

<td><?php echo e($occupiedBeds); ?></td>

<!--<td><?php echo e($availableBeds); ?></td>-->

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<tr style="font-weight:bold; background:#f3f4f6;">
    <td colspan="9" style="text-align:right;">Grand Total Occupied Beds (excluding captains):</td>
    <td><?php echo e($grandTotal); ?></td>
    <td></td>
</tr>

</tbody>

</table>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH /home/enlivetrips.com/public_html/dashboard.enlivetrips.com/resources/views/filament/pages/pdf-layout.blade.php ENDPATH**/ ?>