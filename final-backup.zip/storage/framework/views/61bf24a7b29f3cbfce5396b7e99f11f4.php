<h3
    <?php echo e($attributes->class(['fi-no-notification-title text-sm font-medium text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH /home/enlivetrips.com/public_html/dashboard.enlivetrips.com/vendor/filament/notifications/resources/views/components/title.blade.php ENDPATH**/ ?>