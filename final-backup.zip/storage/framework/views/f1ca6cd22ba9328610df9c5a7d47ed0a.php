<?php if (isset($component)) { $__componentOriginalbe23554f7bded3778895289146189db7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe23554f7bded3778895289146189db7 = $attributes; } ?>
<?php $component = Filament\View\LegacyComponents\Page::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Filament\View\LegacyComponents\Page::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="space-y-6">
        
        <div class="bg-white rounded-xl shadow p-4">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-medium">📅 Select Package & Departure Date</h2>
                
                <!--[if BLOCK]><![endif]--><?php if($date && $package_id): ?>
                    <button 
                        wire:click="toggleFullLayout"
                        class="px-4 py-2 <?php echo e($showFullLayout ? 'bg-gray-500' : 'bg-primary-500'); ?> text-white rounded-lg hover:opacity-90 transition-colors flex items-center gap-2"
                    >
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <!--[if BLOCK]><![endif]--><?php if($showFullLayout): ?>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 10h6"></path>
                            <?php else: ?>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </svg>
                        <?php echo e($showFullLayout ? 'Hide Full Layout' : 'View All Layout'); ?>

                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <?php echo e($this->form); ?>

        </div>

        <!--[if BLOCK]><![endif]--><?php if($date && $package_id): ?>
            
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="bg-white rounded-xl shadow p-4">
                    <div class="flex items-center gap-3">
                        <div class="p-3 bg-blue-100 rounded-lg">
                            <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Total Bookings</p>
                            <p class="text-2xl font-bold"><?php echo e($bookings->count()); ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow p-4">
                    <div class="flex items-center gap-3">
                        <div class="p-3 bg-green-100 rounded-lg">
                            <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Assigned Guests</p>
                            <p class="text-2xl font-bold"><?php echo e(collect($this->roomAssignments)->flatten(1)->count()); ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow p-4">
                    <div class="flex items-center gap-3">
                        <div class="p-3 bg-yellow-100 rounded-lg">
                            <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Unassigned Guests</p>
                            <p class="text-2xl font-bold"><?php echo e(count($this->unassignedGuests)); ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow p-4">
                    <div class="flex items-center gap-3">
                        <div class="p-3 bg-purple-100 rounded-lg">
                            <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Available Beds</p>
                            <p class="text-2xl font-bold"><?php echo e($this->availableRooms->sum('no_of_beds') - collect($this->roomAssignments)->flatten(1)->count()); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            
           <!--[if BLOCK]><![endif]--><?php if($showFullLayout): ?>
           
           <div class="flex justify-end mb-3">
    <button 
        wire:click="downloadLayout"
        class=" text-black px-4 py-2 rounded text-sm"
    >
        Download PDF
    </button>
</div>

    <?php
$data = $this->viewdata();
?>

<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookingId => $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="border rounded-lg mb-6">

        
        <div class="bg-gray-100 px-4 py-2 font-semibold">
            Booking #<?php echo e($bookingId); ?>

        </div>

        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50">
                    <th class="p-2 text-left">Room</th>
                    <th class="p-2 text-left">Type</th>
                   <th class="p-2 text-left">Room Type</th>
                    <th class="p-2 text-left">Bed 1</th>
                    <th class="p-2 text-left">Bed 2</th>
                    <th class="p-2 text-left">Bed 3</th>
                    <th class="p-2 text-left">Bed 4</th>
                    <th class="p-2 text-left">Bed 5</th>
                    <th class="p-2 text-left">Bed 6</th>
                    <th class="p-2 text-left">Total</th>
<th class="p-2 text-left">Available</th>
                </tr>
            </thead>

    <tbody>

<?php
    $sr = 1;
    $grandTotal = 0;
?>

<!--[if BLOCK]><![endif]--><?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomId => $beds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        $room = $beds->first();
        $bedMap = $beds->keyBy('bed_number');
        $totalBeds = $room->room->no_of_beds ?? 6;

        // Captain exclude karke count
        $occupiedBeds = $beds->where('is_captain', 0)->count();
        $availableBeds = $totalBeds - $occupiedBeds;

        $grandTotal += $occupiedBeds;
    ?>

    <tr class="border-b">

        
        <td class="p-2 font-medium">
            <?php echo e($sr++); ?>

        </td>

        
        <td class="p-2">
            <?php echo e(ucfirst($room->room->room_type ?? 'other')); ?>

        </td>

        
        <td class="p-2">
            <?php echo e(ucfirst($room->room_type ?? 'other')); ?>

        </td>

        
        <!--[if BLOCK]><![endif]--><?php for($i = 1; $i <= 6; $i++): ?>
            <td class="p-2">
                <!--[if BLOCK]><![endif]--><?php if(isset($bedMap[$i])): ?>
                    <?php
                        $bed = $bedMap[$i];
                    ?>
                    <div class="bg-blue-50 p-2 rounded">
                        <div class="flex items-center gap-1">
                            <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                            <span class="text-sm">
                                <?php echo e(\Str::limit($bed->guest_name, 12)); ?>

                            </span>
                            <!--[if BLOCK]><![endif]--><?php if($bed->is_captain): ?>
                                <span>👑</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="text-xs text-gray-500">
                            <?php echo e(ucfirst($bed->guest_gender)); ?>

                        </div>
                    </div>
                <?php else: ?>
                    <!--[if BLOCK]><![endif]--><?php if($i <= $totalBeds): ?>
                        <button
                            wire:click="quickAssignBed(<?php echo e($roomId); ?>, <?php echo e($i); ?>)"
                            class="text-xs bg-blue-500 text-white px-2 py-1 rounded"
                        >
                            Assign
                        </button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </td>
        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->

        
        <td class="p-2 font-semibold text-blue-600">
            <?php echo e($occupiedBeds); ?>

        </td>

        
        <td class="p-2 font-semibold text-green-600">
            <?php echo e($availableBeds); ?>

        </td>

    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->


<tr class="bg-gray-100 font-bold">
    <td colspan="9" class="text-right p-2">Grand Total Occupied Beds (excluding captains):</td>
    <td class="p-2 text-blue-600"><?php echo e($grandTotal); ?></td>
    <td></td> 
</tr>

</tbody>
<tfoot>
<tr class="bg-gray-100 font-semibold">
    <td colspan="9" class="p-3 text-right">
        Grand Total Guests : <?php echo e($grandTotal); ?>

    </td>
</tr>
</tfoot>
          
        </table>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            
            <!--[if BLOCK]><![endif]--><?php if($selectedBookingId && $bookingDetails): ?>
                <div class="bg-primary-50 border border-primary-200 rounded-xl p-4">
                    <div class="flex justify-between items-center">
                        <div class="flex items-center gap-3">
                            <div class="p-2 bg-primary-100 rounded-lg">
                                <svg class="w-5 h-5 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm text-primary-600 font-medium">Selected Booking #<?php echo e($bookingDetails->id); ?></p>
                                <p class="text-sm">
                                    <span class="font-medium">Customer:</span> <?php echo e($bookingDetails->customer_name ?? 'No name'); ?> | 
                                    <span class="text-green-600"><?php echo e(count($this->unassignedGuests)); ?> unassigned</span>
                                </p>
                            </div>
                        </div>
                        <button wire:click="clearSelectedBooking" class="px-3 py-1 text-sm bg-white border border-primary-300 rounded-lg hover:bg-primary-50">
                            Clear
                        </button>
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if(!empty($this->unassignedGuests)): ?>
                        <div class="mt-3 pt-3 border-t border-primary-200">
                            <p class="text-sm font-medium mb-2">👥 Unassigned Guests:</p>
                            <div class="flex flex-wrap gap-2">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->unassignedGuests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-sm
                                        <?php if($guest['gender'] == 'female'): ?> bg-pink-100 text-pink-700
                                        <?php elseif($guest['gender'] == 'other'): ?> bg-purple-100 text-purple-700
                                        <?php else: ?> bg-blue-100 text-blue-700
                                        <?php endif; ?>
                                    ">
                                        <?php echo e($guest['name']); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <div class="bg-white rounded-xl shadow p-4">
                <h2 class="text-lg font-medium mb-4">📋 Bookings for <?php echo e($date); ?></h2>
                
                <!--[if BLOCK]><![endif]--><?php if($bookings->isEmpty()): ?>
                    <p class="text-gray-500 text-center py-4">No bookings found for this date</p>
                <?php else: ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $bookingGuests = $this->extractFullPassengerDetails($booking->data_get, $booking->id)['passengers'];
                                $assignedCount = collect($this->roomAssignments)->flatten(1)->where('booking_id', $booking->id)->count();
                                $totalGuests = count($bookingGuests);
                                $unassignedInBooking = $totalGuests - $assignedCount;
                            ?>
                            
                            <div class="border rounded-lg p-4 cursor-pointer transition-all <?php echo e($selectedBookingId == $booking->id ? 'ring-2 ring-primary-500 bg-primary-50' : 'hover:shadow-md'); ?>"
                                 wire:click="selectBooking(<?php echo e($booking->id); ?>)">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <h3 class="font-medium">Booking #<?php echo e($booking->id); ?></h3>
                                        <p class="text-sm text-gray-600"><?php echo e($booking->customer_name ?? 'No name'); ?></p>
                                    </div>
                                    <span class="text-xs px-2 py-1 rounded-full <?php echo e($unassignedInBooking > 0 ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'); ?>">
                                        <?php echo e($assignedCount); ?>/<?php echo e($totalGuests); ?>

                                    </span>
                                </div>
                                
                                <div class="mt-2 w-full bg-gray-200 rounded-full h-1.5">
                                    <div class="bg-primary-600 h-1.5 rounded-full" style="width: <?php echo e($totalGuests > 0 ? ($assignedCount/$totalGuests)*100 : 0); ?>%"></div>
                                </div>

                                <!--[if BLOCK]><![endif]--><?php if($unassignedInBooking > 0): ?>
                                    <p class="text-xs text-yellow-600 mt-2"><?php echo e($unassignedInBooking); ?> guests need assignment</p>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <!--[if BLOCK]><![endif]--><?php if($selectedBookingId && !empty($this->unassignedGuests)): ?>
                <div class="bg-white rounded-xl shadow p-4">
                    <h2 class="text-lg font-medium mb-4">🏨 Select Room</h2>
                    
                    <div class="max-w-md">
                        <select wire:model="selectedRoomId" wire:change="selectRoom($event.target.value)" class="block w-full rounded-lg border-gray-300 focus:border-primary-500 focus:ring-primary-500">
                            <option value="">-- Choose a room --</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->roomOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomId => $roomLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($roomId); ?>"><?php echo e($roomLabel); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <!--[if BLOCK]><![endif]--><?php if($showGenderPrompt && $selectedRoom && !$selectedRoomGender): ?>
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="p-2 bg-blue-100 rounded-lg">
                            <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                            </svg>
                        </div>
                        <div>
                            <h2 class="text-lg font-medium">Who is this room for?</h2>
                            <p class="text-sm text-gray-600">Room: <?php echo e($selectedRoom->room_no ?? 'N/A'); ?> (<?php echo e(ucfirst($selectedRoom->room_type)); ?>)</p>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <button wire:click="setRoomGender('male')"
                                class="p-4 border-2 border-blue-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all">
                            <div class="text-3xl mb-2">♂️</div>
                            <div class="font-medium">Male</div>
                            <div class="text-xs text-gray-500 mt-1"><?php echo e(collect($unassignedGuests)->where('gender', 'male')->count()); ?> guests</div>
                        </button>
                        
                        <button wire:click="setRoomGender('female')"
                                class="p-4 border-2 border-pink-200 rounded-lg hover:border-pink-500 hover:bg-pink-50 transition-all">
                            <div class="text-3xl mb-2">♀️</div>
                            <div class="font-medium">Female</div>
                            <div class="text-xs text-gray-500 mt-1"><?php echo e(collect($unassignedGuests)->where('gender', 'female')->count()); ?> guests</div>
                        </button>
                        
                        <button wire:click="setRoomGender('other')"
                                class="p-4 border-2 border-purple-200 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-all">
                            <div class="text-3xl mb-2">⚧</div>
                            <div class="font-medium">Other</div>
                            <div class="text-xs text-gray-500 mt-1"><?php echo e(collect($unassignedGuests)->where('gender', 'other')->count()); ?> guests</div>
                        </button>
                        
                        <button wire:click="setRoomGender('mixed')"
                                class="p-4 border-2 border-gray-200 rounded-lg hover:border-gray-500 hover:bg-gray-50 transition-all">
                            <div class="text-3xl mb-2">👥</div>
                            <div class="font-medium">Mixed</div>
                            <div class="text-xs text-gray-500 mt-1"><?php echo e(count($unassignedGuests)); ?> total guests</div>
                        </button>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <!--[if BLOCK]><![endif]--><?php if($showRoomLayout && $selectedRoom && $selectedRoomGender): ?>
                <div class="bg-white rounded-xl shadow p-4">
                    <div class="flex justify-between items-center mb-4">
                        <div>
                            <h2 class="text-lg font-medium capitalize"><?php echo e($selectedRoom->room_type); ?> Room Layout</h2>
                            <div class="flex items-center gap-4 mt-1">
                                <p class="text-sm text-gray-600">
                                    <span class="text-green-600 font-medium"><?php echo e($this->getAvailableBedsCount($selectedRoom->id)); ?> available</span> | 
                                    <?php echo e($selectedRoom->no_of_beds - $this->getAvailableBedsCount($selectedRoom->id)); ?> occupied
                                </p>
                                
                                <div class="flex items-center gap-2">
                                    <span class="text-sm text-gray-600">Room No:</span>
                                    <input type="text" 
                                           wire:model="roomNumbers.<?php echo e($selectedRoom->id); ?>" 
                                           placeholder="Enter room no"
                                           value="<?php echo e($selectedRoom->room_no); ?>"
                                           class="w-24 px-2 py-1 text-sm border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500">
                                    <button wire:click="updateRoomNumber(<?php echo e($selectedRoom->id); ?>)"
                                            class="px-2 py-1 text-xs bg-primary-500 text-white rounded-lg hover:bg-primary-600">
                                        Save
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <button wire:click="$set('selectedRoomGender', null); $set('showGenderPrompt', true)" class="text-sm text-gray-500 hover:text-gray-700">
                                Change Gender
                            </button>
                            <button wire:click="$set('showRoomLayout', false); $set('selectedRoomId', null)" class="text-sm text-gray-500 hover:text-gray-700">
                                Change Room
                            </button>
                        </div>
                    </div>

                    
                    <div class="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <div class="flex items-center gap-2">
                            <?php
                                $genderIcon = match($selectedRoomGender) {
                                    'male' => '♂️',
                                    'female' => '♀️',
                                    'other' => '⚧',
                                    'mixed' => '👥',
                                    default => ''
                                };
                            ?>
                            <span class="text-lg"><?php echo e($genderIcon); ?></span>
                            <span class="font-medium">This room is for: <?php echo e(ucfirst($selectedRoomGender)); ?></span>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        <!--[if BLOCK]><![endif]--><?php for($i = 1; $i <= $selectedRoom->no_of_beds; $i++): ?>
                            <?php
                                $guestName = $this->getGuestForBed($selectedRoom->id, $i);
                                $bookingId = $this->getBookingIdForBed($selectedRoom->id, $i);
                                $assignmentId = $this->getAssignmentIdForBed($selectedRoom->id, $i);
                            ?>
                            
                            <div class="relative border-2 rounded-lg p-4 transition-all cursor-pointer
                                        <?php if($guestName): ?>
                                            bg-blue-50 border-blue-400 hover:border-blue-600
                                        <?php else: ?>
                                            bg-green-50 border-green-400 hover:border-green-600 hover:shadow-md
                                        <?php endif; ?>"
                                 wire:click="selectBed(<?php echo e($selectedRoom->id); ?>, <?php echo e($i); ?>)">
                                
                                <div class="absolute -top-3 -left-3 w-8 h-8 rounded-full bg-gray-800 text-white flex items-center justify-center font-bold shadow-lg">
                                    <?php echo e($i); ?>

                                </div>
                                
                                <div class="mt-2 text-center">
                                    <!--[if BLOCK]><![endif]--><?php if($guestName): ?>
                                        <div class="text-sm font-medium text-blue-700 truncate" title="<?php echo e($guestName); ?>">
                                            <?php echo e(\Str::limit($guestName, 12)); ?>

                                        </div>
                                        <div class="text-xs text-gray-500 mt-1">#<?php echo e($bookingId); ?></div>
                                        <button wire:click="removeGuestFromBed(<?php echo e($selectedRoom->id); ?>, <?php echo e($i); ?>)"
                                                class="mt-2 text-xs text-red-500 hover:text-red-700"
                                                onclick="event.stopPropagation(); return confirm('Remove guest from this bed?')">
                                            Remove
                                        </button>
                                    <?php else: ?>
                                        <div class="text-sm text-gray-600 font-medium">Available</div>
                                        <div class="mt-2 text-xs text-green-600">Click to assign</div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                
                                <div class="mt-2 text-center <?php echo e($guestName ? 'text-blue-400' : 'text-green-400'); ?>">
                                    <svg class="w-8 h-8 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4M20 12v6M4 12v6M4 12V6a2 2 0 012-2h12a2 2 0 012 2v6"></path>
                                    </svg>
                                </div>
                            </div>
                        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($this->getAvailableBedsCount($selectedRoom->id) > 0 && !empty($this->unassignedGuests)): ?>
                        <div class="mt-4 text-center">
                            <button wire:click="openBulkAssign(<?php echo e($selectedRoom->id); ?>)"
                                    class="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors">
                                Bulk Assign Multiple Guests
                            </button>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <?php if (isset($component)) { $__componentOriginal0942a211c37469064369f887ae8d1cef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0942a211c37469064369f887ae8d1cef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.modal.index','data' => ['id' => 'select-guest-modal','width' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'select-guest-modal','width' => 'lg']); ?>
         <?php $__env->slot('heading', null, []); ?> 
            <div class="flex items-center gap-2">
                <span>Select Guest for Bed #<?php echo e($selectedBedNumber); ?></span>
                <!--[if BLOCK]><![endif]--><?php if($selectedRoomGender): ?>
                    <span class="text-sm font-normal px-2 py-1 rounded-full 
                        <?php if($selectedRoomGender == 'male'): ?> bg-blue-100 text-blue-700
                        <?php elseif($selectedRoomGender == 'female'): ?> bg-pink-100 text-pink-700
                        <?php elseif($selectedRoomGender == 'other'): ?> bg-purple-100 text-purple-700
                        <?php else: ?> bg-gray-100 text-gray-700
                        <?php endif; ?>
                    ">
                        <?php
                            $genderIcon = match($selectedRoomGender) {
                                'male' => '♂️',
                                'female' => '♀️',
                                'other' => '⚧',
                                'mixed' => '👥',
                                default => ''
                            };
                        ?>
                        <?php echo e($genderIcon); ?> <?php echo e(ucfirst($selectedRoomGender)); ?> Room
                    </span>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
         <?php $__env->endSlot(); ?>
        
        <div class="space-y-4">
            
              <div class="text-center py-8">
                    <svg class="w-16 h-16 mx-auto text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    
                    <div class="space-y-4">
                        <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                            
                             <input type="checkbox" 
       value="<?php echo e($package_id); ?>"
       wire:click="toggleGuestSelection22(<?php echo e($package_id); ?>, <?php echo e($selectedBookingId); ?>, '<?php echo e($date); ?>', <?php echo e($selectedRoomId); ?>, <?php echo e($selectedBedNumber); ?>)"
       class="w-5 h-5 rounded border-gray-300 text-primary-600 focus:ring-primary-500 cursor-pointer"
       <?php echo e(in_array($package_id, $selectedGuests) ? 'checked' : ''); ?>>

                            <h4 class="text-sm font-medium text-gray-700 mb-3">📋 Assignment Details</h4>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <p class="text-xs text-gray-500">Package ID</p>
                                    <p class="font-medium text-gray-800">#<?php echo e($package_id); ?></p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500">Booking ID</p>
                                    <p class="font-medium text-gray-800">#<?php echo e($selectedBookingId); ?></p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500">Start Date</p>
                                    <p class="font-medium text-gray-800"><?php echo e($date); ?></p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500">Room</p>
                                    <p class="font-medium text-gray-800">#<?php echo e($selectedRoomId); ?> (Bed #<?php echo e($selectedBedNumber); ?>)</p>
                                </div>
                            </div>
                        </div>

                        <p class="text-gray-500 mt-2">No unassigned guests available</p>
                    </div>
                </div>
            <!--[if BLOCK]><![endif]--><?php if(empty($unassignedGuests)): ?>
              
            <?php else: ?>
                <div class="space-y-2 max-h-96 overflow-y-auto">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $unassignedGuests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-all"
                             wire:click="assignGuestToBed('<?php echo e($guest['id']); ?>')">
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <h4 class="font-medium text-lg"><?php echo e($guest['name']); ?></h4>
                                    <div class="flex items-center gap-3 mt-2">
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm
                                            <?php if($guest['gender'] == 'female'): ?> bg-pink-100 text-pink-700
                                            <?php elseif($guest['gender'] == 'other'): ?> bg-purple-100 text-purple-700
                                            <?php else: ?> bg-blue-100 text-blue-700
                                            <?php endif; ?>
                                        ">
                                            <?php echo e(ucfirst($guest['gender'])); ?>

                                        </span>
                                        <span class="text-sm text-gray-600">
                                            <span class="font-medium">Sharing:</span> <?php echo e($guest['sharing_type']); ?>

                                        </span>
                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php if($guest['contact']): ?>
                                        <p class="text-sm text-gray-500 mt-2">
                                            📞 <?php echo e($guest['contact']); ?>

                                        </p>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <svg class="w-6 h-6 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                </svg>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        
         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'gray','wire:click' => '$dispatch(\'close-modal\', {id: \'select-guest-modal\'})']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','wire:click' => '$dispatch(\'close-modal\', {id: \'select-guest-modal\'})']); ?>
                Cancel
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $attributes = $__attributesOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__attributesOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $component = $__componentOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__componentOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginal0942a211c37469064369f887ae8d1cef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0942a211c37469064369f887ae8d1cef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.modal.index','data' => ['id' => 'bulk-assign-modal','width' => '2xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'bulk-assign-modal','width' => '2xl']); ?>
         <?php $__env->slot('heading', null, []); ?> 
            Assign Multiple Guests to <?php echo e($selectedRoom ? ucfirst($selectedRoom->room_type) : ''); ?> Room
         <?php $__env->endSlot(); ?>
        
        <div class="space-y-4">
            <!--[if BLOCK]><![endif]--><?php if(empty($unassignedGuests)): ?>
                <div class="text-center py-8">
                    <svg class="w-16 h-16 mx-auto text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <p class="text-gray-500 mt-2">No unassigned guests available</p>
                </div>
            <?php else: ?>
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <p class="text-sm text-blue-700">
                        <span class="font-medium">Available beds in this room:</span> <?php echo e($selectedRoom ? $this->getAvailableBedsCount($selectedRoom->id) : 0); ?>

                    </p>
                    <!--[if BLOCK]><![endif]--><?php if($selectedRoomGender && $selectedRoomGender != 'mixed'): ?>
                        <p class="text-xs text-blue-600 mt-1">
                            ⚠️ This room is for <strong><?php echo e(ucfirst($selectedRoomGender)); ?></strong> guests only.
                        </p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                
                <div class="grid grid-cols-1 gap-3 max-h-96 overflow-y-auto">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $unassignedGuests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                            <label class="flex items-start gap-4 cursor-pointer">
                                <input type="checkbox" 
                                       value="<?php echo e($guest['id']); ?>"
                                       wire:click="toggleGuestSelection('<?php echo e($guest['id']); ?>')"
                                       class="mt-1 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                                       <?php echo e(in_array($guest['id'], $selectedGuests) ? 'checked' : ''); ?>>
                                <div class="flex-1">
                                    <div class="flex items-center justify-between">
                                        <h4 class="font-medium text-lg"><?php echo e($guest['name']); ?></h4>
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs
                                            <?php if($guest['gender'] == 'female'): ?> bg-pink-100 text-pink-700
                                            <?php elseif($guest['gender'] == 'other'): ?> bg-purple-100 text-purple-700
                                            <?php else: ?> bg-blue-100 text-blue-700
                                            <?php endif; ?>
                                        ">
                                            <?php echo e(ucfirst($guest['gender'])); ?>

                                        </span>
                                    </div>
                                    <div class="flex items-center gap-4 mt-2">
                                        <span class="text-sm text-gray-600">
                                            <span class="font-medium">Sharing:</span> <?php echo e($guest['sharing_type']); ?>

                                        </span>
                                        <!--[if BLOCK]><![endif]--><?php if($guest['contact']): ?>
                                            <span class="text-sm text-gray-600">
                                                📞 <?php echo e($guest['contact']); ?>

                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                
                <div class="flex justify-between items-center pt-4 border-t">
                    <div>
                        <span class="text-sm font-medium text-gray-700"><?php echo e(count($selectedGuests)); ?> guests selected</span>
                        <!--[if BLOCK]><![endif]--><?php if(count($selectedGuests) > ($selectedRoom ? $this->getAvailableBedsCount($selectedRoom->id) : 0)): ?>
                            <p class="text-xs text-red-500 mt-1">Selected more guests than available beds!</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->  
                    </div>
                    <div class="flex gap-2">
                        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'gray','wire:click' => '$set(\'selectedGuests\', [])']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','wire:click' => '$set(\'selectedGuests\', [])']); ?>
                            Clear All
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['wire:click' => 'assignMultipleGuests','disabled' => empty($selectedGuests) || count($selectedGuests) > ($selectedRoom ? $this->getAvailableBedsCount($selectedRoom->id) : 0)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'assignMultipleGuests','disabled' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(empty($selectedGuests) || count($selectedGuests) > ($selectedRoom ? $this->getAvailableBedsCount($selectedRoom->id) : 0))]); ?>
                            Assign Selected
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        
         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'gray','wire:click' => '$dispatch(\'close-modal\', {id: \'bulk-assign-modal\'})']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','wire:click' => '$dispatch(\'close-modal\', {id: \'bulk-assign-modal\'})']); ?>
                Close
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $attributes = $__attributesOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__attributesOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $component = $__componentOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__componentOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $attributes = $__attributesOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__attributesOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $component = $__componentOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__componentOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?><?php /**PATH /home/enlivetrips.com/public_html/dashboard.enlivetrips.com/resources/views/filament/pages/stay-layout.blade.php ENDPATH**/ ?>