<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Trips;
use App\Models\Destinations;
use Illuminate\Http\Request;
use Carbon\Carbon;
class TripController extends Controller
{
    public function index(Request $request)
    {
        $trips = Trips::all();
        return response()->json($trips);
    }
  
public function single_trips(Request $request, $slug)
{
    $trip = Trips::where('slug', $slug)->firstOrFail();

    $packages = $trip->packages()
        ->select(
            'id',
            'thumbnail',
            'title',
            'slug',
            'duration',
            'starting_price',
            'pickup',
            'drop',
            'is_trending'
        )
        ->where('is_active', true)

        // ✅ Only include packages with valid upcoming dates
        ->whereHas('packageDates', function ($query) {
            $query->where('start_date', '>', Carbon::today())
                  ->where('status', '!=', 'closed');
        })

        ->with([
            'packageDates' => function ($query) {
                $query->where('start_date', '>', Carbon::today())
                      ->where('status', '!=', 'closed')
                      ->orderBy('start_date', 'asc'); // better than id
            }
        ])

        ->orderByDesc('is_trending') // optional
        ->get();

    return response()->json([
        'trip' => $trip,
        'packages' => $packages
    ]);
}
    public function home_trips()
    {
        $home = Trips::select(['id','heading','slug','thumbnail'])->where('show_in_home', 1)->get();
        return response()->json($home);
    }
    public function trips_with_packagecount()
    {
        
        $trips = Trips::withCount([
                'packages as active_packages_count' => function ($query) {
                    $query->where('is_active', true);
                }
            ])
            
            ->having('active_packages_count', '>', 0) // sirf jinke active package hain
            ->get()
            ->makeHidden(['content', 'banner', 'thumbnail','meta_title','meta_description','meta_keywords']);
    // return $trips;
        return response()->json($trips);
    }
    
    public function trips_with_destination()
    {
        $trips = Trips::all();
        $destinations = Destinations::all();
    
        return response()->json(['trips' => $trips, 'destinations' => $destinations]);
    }
}
